# マケデコ optiver解法勉強会

- `slide`がMarpスライド
- `notebook`に実験コード

SpeakerDeck: https://speakerdeck.com/richwomanbtc/optiver-trading-at-the-close-shang-wei-jie-fa-matome